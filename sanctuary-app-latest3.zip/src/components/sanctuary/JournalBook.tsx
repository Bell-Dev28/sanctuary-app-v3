'use client';
import { useRouter } from 'next/navigation';

export default function JournalBook({ journal }) {
  const router = useRouter();
  return (
    <div className="p-4 bg-muted rounded cursor-pointer" onClick={() => router.push(`/journal/${journal.id}`)}>
      <h3 className="font-bold">{journal.title}</h3>
    </div>
  );
}