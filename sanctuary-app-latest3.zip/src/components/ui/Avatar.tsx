
import * as React from 'react';
import { Avatar as RadixAvatar, AvatarFallback, AvatarImage } from '@radix-ui/react-avatar';

export function Avatar({ src, fallback }: { src?: string; fallback: string }) {
  return (
    <RadixAvatar className="h-10 w-10 rounded-full border">
      <AvatarImage src={src} />
      <AvatarFallback>{fallback}</AvatarFallback>
    </RadixAvatar>
  );
}
