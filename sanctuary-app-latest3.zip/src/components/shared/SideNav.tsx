
'use client';

import useUser from '@/hooks/useUser';
import { Avatar } from '@/components/ui/Avatar';

export default function SideNav() {
  const { user } = useUser();

  return (
    <div className="w-64 bg-gray-100 p-4">
      <div className="mb-4">
        <Avatar src={user?.email || ''} fallback="?" />
        <p className="mt-2">{user?.email}</p>
      </div>
    </div>
  );
}
