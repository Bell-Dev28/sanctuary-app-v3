
import { cn } from "@/lib/utils";

export default function FavoriteCard({ title, description }: { title: string; description: string }) {
  return (
    <div className={cn("p-4 border rounded-md shadow-sm")}>
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="text-sm text-gray-600">{description}</p>
    </div>
  );
}
