import { clsx, ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

/**
 * Combines class names with conditional logic and merges Tailwind classes.
 *
 * @param inputs - Accepts any number of class name strings, arrays, or conditionals.
 * @returns A single merged class name string.
 */
export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(...inputs));
}
