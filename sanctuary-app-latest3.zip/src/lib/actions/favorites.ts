
import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';

export async function fetchFavoritesByUser() {
  const cookieStore = cookies();
  const supabase = createServerClient({ cookies: () => cookieStore });

  const { data, error } = await supabase.from('favorites').select('*');
  if (error) throw new Error(error.message);
  return data;
}
