import JournalBook from '@/components/sanctuary/JournalBook';

export default async function LibraryPage() {
  const journals = []; // Fetch from Supabase or props
  return (
    <div className="p-6 grid grid-cols-2 gap-4">
      {journals.map((j) => <JournalBook key={j.id} journal={j} />)}
    </div>
  );
}